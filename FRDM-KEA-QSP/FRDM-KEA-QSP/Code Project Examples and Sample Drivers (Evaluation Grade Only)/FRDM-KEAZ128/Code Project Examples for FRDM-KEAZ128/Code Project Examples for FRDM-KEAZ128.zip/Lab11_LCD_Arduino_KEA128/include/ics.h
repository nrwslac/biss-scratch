/*
 * ics.h
 *
 *  Created on: Nov 6, 2015
 *      Author: B48683
 */

#ifndef ICS_H_
#define ICS_H_

/***************************************************************
 * Custom writing this file for this demo because the SDK macros conflict with the MSF Arduino library and the MSF
 * library does not have a clock initialization function.
 **************************************************************/

void ICS_Init_FEI(void);

#endif /* ICS_H_ */
