This driver is meant for use in Arduino applications and is not compatible with the standard KEA SDK.  Place Boards.h and msf_config.h
inside the "include" folder of your project and integrate the "MSF" folder by following the same steps as KEA SDK integration
outlined in the software integration guide.