/*******************************************************************************
*
* (c) Copyright 2014 Freescale Semiconductor
*
****************************************************************************//*!
*
* @file     adc.c
*
* @author   B06050
*
* @version  1.0.2.0
*
* @date     Jul-3-2014
*
* @brief    Analog-to-Digital Converter SW module source file.
*
*******************************************************************************/
#include "adc.h"

/*******************************************************************************
* Global functions
*******************************************************************************/
/*******************************************************************************
*
* Function: void ADC_Init(void)
*
* Description:  This function initializes the ADC module.
*
*******************************************************************************/
void ADC_Init(void)
{
    /* Clock div. by 2, 12-bit resolution, alternate clock (OSC_OUT) */
    ADC_SC3 = ADC_SC3_ADIV(1) | ADC_SC3_MODE(2) | ADC_SC3_ADICLK(2);
    /* Disable I/O control on analog inputs S12..SE11, SE7..SE4, SE1..SE0 */
    ADC_APCTL1 = ADC_APCTL1_ADPC(0x18F3);
}

/*******************************************************************************
*
* Function: void ADC_StartSingleConversion(uint8_t ui8Channel)
*
* Description:  This function disables triggered conversions and starts single
*               channel conversion (12-bit). Conversion complete interrupt is
*               disabled.
*
* Param[in]:    ui8Channel  ADC channel number
*
*******************************************************************************/
void ADC_StartSingleConversion(uint8_t ui8Channel)
{
    /* FIFO disabled */
    ADC_SC4 = 0x00000000;
    /* Software trigger selected */
    ADC_SC2 = 0x00000000;
    /* Start conversion of the selected channel */
    ADC_SC1 = ADC_SC1_ADCH(ui8Channel);
}

/*******************************************************************************
*
* Function: void ADC_EnableTrigSeq(uint8_t *pChannelList, uint8_t ui8FifoDepth)
*
* Description:  This function enables conversion sequence triggered HW trigger
*               input. Conversion complete complete interrupt enabled.
*
* Param[in]:    *pChannelList   Pointer to the list of channels
*               ui8FifoDepth    ADC channel FIFO depth (number of channels)
*
*******************************************************************************/
void ADC_EnableTrigSeq(uint8_t *pChannelList, uint8_t ui8FifoDepth)
{
    uint8_t ui8ChannelCnt;
#ifdef MCU_SKEAZ1284
    /* Mask HW trigger if data FIFO not empty */
    ADC_SC5 = ADC_SC5_HTRGMASKSEL_MASK;

    /* HW trigger pulse triggers multiple conversions in FIFO mode */
    ADC_SC4 = ADC_SC4_HTRGME_MASK | ADC_SC4_AFDEP(ui8FifoDepth - 1);
#elif defined(MCU_SKEAZN642)  //SKEAZN642 has not Hardware Trigger Multiple Conversion
    ADC_SC4=ADC_SC4_ADFDEP(ui8FifoDepth -1);
#endif
    /* HW trigger selected */
    ADC_SC2 = ADC_SC2_ADTRG_MASK;

    /* Initialize channel FIFO */
    for(ui8ChannelCnt=0; ui8ChannelCnt<ui8FifoDepth-1; ui8ChannelCnt++)
    {
        ADC_SC1 = *(pChannelList + ui8ChannelCnt);
    }

    /* Define the last channel in FIFO, enable conversion complete interrupt */
    ADC_SC1 = ADC_SC1_AIEN_MASK | *(pChannelList + ui8ChannelCnt);
}

/***********************************************************************************************
*
* @brief    ADC_Init - Initiates the Channel to read the value of the ADC channel
*
* @param    Channel to init and resolution
* @return   none
*
************************************************************************************************/
void ADC_Init2(UINT8 channel, UINT8 mode)
{
	SIM_SCGC |= SIM_SCGC_ADC_MASK;				/* Enable bus clock in ADC*/
	ADC_SC3 |= ADC_SC3_ADICLK(0b00);			/* Bus clock selected*/
	ADC_SC2 |= 0x00;							/* Software Conversion trigger, disable compare function*/
	ADC_SC1 = 0	;								/* Enable ADC by setting ADCH bits as low*/
	ADC_SC1|= ADC_SC1_ADCO_MASK;  				/* Continuous mode operation */
	ADC_APCTL1 |= ADC_APCTL1_ADPC(1<<channel);  /* Channel selection */
	ADC_SC3 |= ADC_SC3_MODE(mode);				/* 8,10,12 bit mode operation */
}

/***********************************************************************************************
*
* @brief    ADC_Read - Read the selected ADC channel
* @param    ch - channel to read
* @return   result
*
************************************************************************************************/
UINT16 ADC_Read(UINT8 channel)
{

	ADC_SC1 |= ADC_SC1_ADCH(channel);		/* Select channel to read */
	while(!(ADC_SC1 & ADC_SC1_COCO_MASK));	/* Wait conversion to complete */
	return ADC_R;							/* Return adc value */

}
