/*******************************************************************************
*
* (c) Copyright 2014 Freescale Semiconductor
*
****************************************************************************//*!
*
* @file     adc.h
*
* @author   B06050
*
* @version  1.0.2.0
*
* @date     Jul-3-2014
*
* @brief    Analog-to-Digital Converter SW module header file.
*
*******************************************************************************/
#ifndef ADC_H_
#define ADC_H_

/*******************************************************************************
* Includes
*******************************************************************************/
#include "derivative.h"
#include "typedefs.h"

/*******************************************************************************
* Constants and macros
*******************************************************************************/
/* Analog channel assignments */
#define ADC_DCBV    11      /* DC bus voltage */
#define ADC_DCBI    1       /* DC bus current */
#define ADC_BEMFA   6       /* Phase A voltage */
#define ADC_BEMFB   7       /* Phase B voltage */
#define ADC_BEMFC   12      /* Phase C voltage */

#define EIGHT_BIT 	0
#define TEN_BIT 	1
#define TWELVE_BIT 	2

/*******************************************************************************
* Global function prototypes
*******************************************************************************/
void ADC_Init(void);
void ADC_StartSingleConversion(uint8_t ui8Channel);
void ADC_EnableTrigSeq(uint8_t *pChannelList, uint8_t ui8FifoDepth);
/***********************************************************************************************
*
* @brief    ADC_Init - Initiates the Channeln to read the value of the ADC channel
*
* @param    Channel to init and resolution
* @return   none
*
************************************************************************************************/
void ADC_Init2(UINT8 channel, UINT8 mode);

/***********************************************************************************************
*
* @brief    ADC_Read - Read the selected ADC channel
* @param    ch - channel to read
* @return   result
*
************************************************************************************************/
UINT16 ADC_Read(UINT8 channel);

#endif /* ADC_H_ */
