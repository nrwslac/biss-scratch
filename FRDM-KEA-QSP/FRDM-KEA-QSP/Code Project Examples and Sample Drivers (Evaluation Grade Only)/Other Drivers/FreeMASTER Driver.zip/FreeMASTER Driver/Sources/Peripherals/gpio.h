/*******************************************************************************
*
* (c) Copyright 2014 Freescale Semiconductor
*
****************************************************************************//*!
*
* @file     gpio.h
*
* @author   B06050
*
* @version  1.0.3.0
*
* @date     Jul-3-2014
*
* @brief    General-Purpose Input/Output SW module header file.
*
*******************************************************************************/
#ifndef GPIO_H_
#define GPIO_H_

/*******************************************************************************
* Includes
*******************************************************************************/
#include "derivative.h"

/*******************************************************************************
* Constants and macros
*******************************************************************************/
/* Serial Peripheral Interface SPI0  */
#define SCLK0                       /* PTE2/SCK0  */
#define MOSI0                       /* PTE3/MOSI0 */
#define MISO0                       /* PTE4/MISO0 */

/* SBC - MC33903S pin assignments */
#define MC33903_SCLK                /* PTE0/SCK0     */
#define MC33903_MOSI                /* PTE1/MOSI0    */
#define MC33903_MISO                /* PTE2/MISO0    */
#define MC33903_CS                  /* PTC5          */
#define MC33903_INT                 /* PTD1          */
#define MC33903_RST                 /* RESET         */
#define MC33903_LIN_RX              /* PTA2/UART0_RX */
#define MC33903_LIN_TX              /* PTA3/UART0_TX */
#define MC33903_CAN_RX              /* PTC6/CAN0_RX  */
#define MC33903_CAN_TX              /* PTC7/CAN0_TX  */
#define UART2_RX                    /* PTI0/UART2_RX */
#define UART2_TX                    /* PTI1/UART2_TX */

#define MC33903_CS_LOW              GPIOA_PCOR = 0x00200000
#define MC33903_CS_HIGH             GPIOA_PSOR = 0x00200000

#define MC33937_CS_LOW              GPIOB_PCOR = 0x20000000
#define MC33937_CS_HIGH             GPIOB_PSOR = 0x20000000
#define MC33937_EN_SET              GPIOA_PSOR = 0x01000000
#define MC33937_EN_CLEAR            GPIOA_PCOR = 0x01000000
#define MC33937_RST_SET             GPIOB_PSOR = 0x80000000
#define MC33937_RST_CLEAR           GPIOB_PCOR = 0x80000000

#define MC33937_INT                 ((GPIOB_PDIR & 0x40000000) >> 30)

#define BRAKE_PWM_ON                GPIOA_PSOR = 0x00002000
#define BRAKE_PWM_OFF               GPIOA_PCOR = 0x00002000

#define LED_GREEN_ON                GPIOB_PCOR = 0x01000000
#define LED_GREEN_OFF               GPIOB_PSOR = 0x01000000
#define LED_GREEN_TOGGLE            GPIOB_PTOR = 0x01000000
#define LED_RED_ON                  GPIOB_PCOR = 0x02000000
#define LED_RED_OFF                 GPIOB_PSOR = 0x02000000
#define LED_RED_TOGGLE              GPIOB_PTOR = 0x02000000

#ifdef MCU_SKEAZ1284
#define SW_RUN_R                    ((GPIOC_PDIR & 0x00000020) >> 5)
#define SW_RUN_L                    ((GPIOC_PDIR & 0x00000040) >> 6)

#elif defined(MCU_SKEAZN642)

#endif

#define SWB0                        ((GPIOA_PDIR & 0x20000000) >> 29)
#define SWB1                        ((GPIOA_PDIR & 0x40000000) >> 30)

#define PTH0 24 //RED
#define PTH1 25 //GREEN
#define PTE7 7  //BLUE
#define PTE4 4  //BTN0
#define PTE5 5  //BTN1
#define PTC2 18 //POTENTIOMETER

#define LED0_TOGGLE		OUTPUT_TOGGLE(H1,PTH0)
#define LED1_TOGGLE		OUTPUT_TOGGLE(H1,PTH1)
#define LED2_TOGGLE		OUTPUT_TOGGLE(E1,PTE7)

#define LED0_OFF		OUTPUT_CLEAR(H1,PTH0);
#define LED1_OFF		OUTPUT_CLEAR(H1,PTH1);
#define LED2_OFF		OUTPUT_CLEAR(E1,PTE7);

#define LED0_ON			OUTPUT_SET(H1,PTH0);
#define LED1_ON			OUTPUT_SET(H1,PTH1);
#define LED2_ON			OUTPUT_SET(E1,PTE7);

#define A1  A
#define B1  A
#define C1  A
#define D1  A

#define E1	B
#define F1	B
#define G1	B
#define H1	B

#define I1	C

#define OUTPUT  1
#define INPUT	0

#define CONFIG_PIN_AS_GPIO(port,port_pin,mode)    XCONFIG_PIN_AS_GPIO(port,port_pin,mode)
#define XCONFIG_PIN_AS_GPIO(port,port_pin,mode)   (mode == 0) ? (GPIO##port##_PDDR |= 0 << port_pin) : (GPIO##port##_PDDR |= 1 << port_pin)

#define ENABLE_INPUT(port,port_pin) 				XENABLE_INPUT(port,port_pin)
#define XENABLE_INPUT(port,port_pin)				GPIO##port##_PIDR ^= 1<<port_pin

#define ENABLE_PULLUP(port,port_pin) 				XENABLE_PULLUP(port,port_pin)
#define XENABLE_PULLUP(port,port_pin) 				PORT_PUE0 |= PORT_PUE0_PT##port##PE##port_pin##_MASK

#define OUTPUT_SET(port,register_num)				XOUTPUT_SET(port,register_num)
#define XOUTPUT_SET(port,register_num)				GPIO##port##_PCOR |=1<<register_num

#define OUTPUT_CLEAR(port,register_num)				XOUTPUT_CLEAR(port,register_num)
#define XOUTPUT_CLEAR(port,register_num)			GPIO##port##_PSOR |=1<<register_num

#define OUTPUT_TOGGLE(port,register_num)			XOUTPUT_TOGGLE(port,register_num)
#define XOUTPUT_TOGGLE(port,register_num)			GPIO##port##_PTOR |=1<<register_num

#define CONFIG_PIN_AS_FGPIO(port,port_pin,mode)    XCONFIG_PIN_AS_FGPIO(port,port_pin,mode)
#define XCONFIG_PIN_AS_FGPIO(port,port_pin,mode)   (mode == 0) ? (FGPIO##port##_PDDR |= 0 << port_pin) : (FGPIO##port##_PDDR |= 1 << port_pin)

/*******************************************************************************
* Global function prototypes
*******************************************************************************/
void GPIO_Init(void);

void GPIO_Init2(void);

#endif /* GPIO_H_ */
