/*******************************************************************************
*
* (c) Copyright 2014 Freescale Semiconductor
*
****************************************************************************//*!
*
* @file     ftm.h
*
* @author   B06050
*
* @version  1.0.2.0
*
* @date     Jul-3-2014
*
* @brief    FlexTimer SW module header file.
*
*******************************************************************************/
#ifndef FTM_H_
#define FTM_H_

/*******************************************************************************
* Includes
*******************************************************************************/
#include "derivative.h"
#include "KEA128_appconfig.h"
#include "typedefs.h"

/*******************************************************************************
* Constants and macros
*******************************************************************************/
#define FTM0_PERIOD_1MS     749     /* 1ms timeout @750kHz FTM0 clock */

#define FTM0_UPDATE_MOD(modulo)     FTM0_SC &= ~FTM_SC_CLKS_MASK; \
                                    FTM0_MOD = modulo; \
                                    FTM0_SC |= FTM_SC_CLKS(1)

/*******************************************************************************
* Global function prototypes
*******************************************************************************/
void FTM0_Init(void);
void FTM1_Init(void);
void FTM2_Init(void);

/***********************************************************************************************
*
* @brief    FTM_Init - Initialize the FTM counter and enable 4 interrupts (CH0 to CH3)
* @param    none
* @return   none
*
************************************************************************************************/
void FTM_Init();

/***********************************************************************************************
*
* @brief    FTM_SetPeriod - Set the period of the periodic interrupt
* @param    ch - channel to configure, per - period to set
* @return   none
*
************************************************************************************************/
void FTM_SetPeriod(UINT8 ch, UINT32 per);

#endif /* FTM_H_ */
