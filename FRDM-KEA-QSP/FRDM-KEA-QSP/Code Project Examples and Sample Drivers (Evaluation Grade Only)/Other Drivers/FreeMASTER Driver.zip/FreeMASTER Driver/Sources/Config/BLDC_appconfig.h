/**********************************************************************/
// File Name: {FM_project_loc}/Sources/Config/BLDC_appconfig.h 
//
// Date:  4. July, 2014
//
// Automatically generated file for static configuration of the BLDC application
/**********************************************************************/

#ifndef __BLDC_CONFIG_SETUP_H
#define __BLDC_CONFIG_SETUP_H


//Motor Parameters                      
//----------------------------------------------------------------------
//Pole-pair number                      = 4 [-]
//Back-EMF constant                     = 0.0129 [V.sec/rad]
//Phase current nominal                 FRAC16(0.139198886409)
//Phase voltage nominal                 FRAC16(0.480000000000)
//----------------------------------------------------------------------

//Application scales                    
#define I_MAX                           (41.667)
#define U_DCB_MAX                       (25.0)
#define N_MAX                           (10000.0)
#define I_DCB_OVERCURRENT               FRAC16(0.359997120023)
#define U_DCB_UNDERVOLTAGE              FRAC16(0.360000000000)
#define U_DCB_OVERVOLTAGE               FRAC16(0.800000000000)
#define I_DCB_LIMIT                     FRAC16(0.071999424005)
#define U_DCB_TRIP                      FRAC16(0.680000000000)
#define N_NOM                           FRAC16(0.935000000000)
#define I_PH_NOM                        FRAC16(0.139198886409)
#define U_PH_NOM                        FRAC16(0.480000000000)
//Mechanical Alignment                  
#define ALIGN_VOLTAGE                   FRAC16(0.125000000000)
#define ALIGN_DURATION                  (200)

//BLDC Control Loop                     
//----------------------------------------------------------------------
//Loop sample time                      = 0.001 [sec]
//----------------------------------------------------------------------
//Control loop limits                   
#define CTRL_LOOP_LIM_HIGH              FRAC16(0.900000000000)
#define CTRL_LOOP_LIM_LOW               FRAC16(0.100000000000)

//Speed Controller - Parallel type      
#define SPEED_LOOP_KP_GAIN              FRAC16(0.514714422649)
#define SPEED_LOOP_KP_SHIFT             (-8)
#define SPEED_LOOP_KI_GAIN              FRAC16(0.643393028311)
#define SPEED_LOOP_KI_SHIFT             (-7)

//Speed ramp increments                 
#define SPEED_LOOP_RAMP_UP              FRAC32(0.003000000000)
#define SPEED_LOOP_RAMP_DOWN            FRAC32(0.002000000000)

//Torque Controller - Parallel type     
#define TORQUE_LOOP_KP_GAIN             FRAC16(0.666672000000)
#define TORQUE_LOOP_KP_SHIFT            (-3)
#define TORQUE_LOOP_KI_GAIN             FRAC16(0.800006400000)
#define TORQUE_LOOP_KI_SHIFT            (-5)
#define TORQUE_LOOP_MAF                 (5)

//Sensorless Control Module             
//----------------------------------------------------------------------
//Timer Frequency                       = 750000 [Hz]
//----------------------------------------------------------------------
#define N_MIN                           FRAC16(0.080000000000)
#define N_START_TRH                     FRAC16(0.080000000000)
#define STARTUP_CMT_CNT                 (8)
#define STARTUP_CMT_PER                 (30000)
#define CMT_T_OFF                       FRAC16(0.250000000000)
#define FREEWHEEL_T_LONG                (1000)
#define FREEWHEEL_T_SHORT               (500)
#define SPEED_SCALE_CONST               (1125)
#define CMT_PER_MIN                     (188)
#define START_CMT_ACCELER               FRAC16(0.694747747187)
#define INTEG_TRH                       (0)

//FreeMASTER Scale Variables            
//----------------------------------------------------------------------
//Note: Scaled at input = 1000          
//----------------------------------------------------------------------
#define FM_I_SCALE                      (41667)
#define FM_U_DCB_SCALE                  (25000)
#define FM_N_SCALE                      (10000000)

#endif
/**********************************************************************/
/**********************************************************************/
