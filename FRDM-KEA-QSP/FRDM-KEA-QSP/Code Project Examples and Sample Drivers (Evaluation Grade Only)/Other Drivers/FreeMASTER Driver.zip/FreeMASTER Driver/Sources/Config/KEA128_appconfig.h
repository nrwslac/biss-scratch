/*******************************************************************************
*
* (c) Copyright 2014 Freescale Semiconductor
*
****************************************************************************//*!
*
* @file     KEA128_appconfig.h
*
* @author   B06050
*
* @version  1.0.6.0
*
* @date     Aug-29-2014
*
* @brief    KEA128 BLDC sensorless motor control application configuration
*           parameter header file.
*
*******************************************************************************/
#ifndef KEA128_APPCONFIG_H_
#define KEA128_APPCONFIG_H_

/*******************************************************************************
* Includes
*******************************************************************************/
#include "BLDC_appconfig.h"

/*******************************************************************************
* Constants and macros
*******************************************************************************/
/* next_cmt = TimeWhenZCfound + ZC_period * ADVANCE_ANGLE */
#define ADVANCE_ANGLE   FRAC16(0.3815)      /* 12500 */

/* PWM period in FTM2 ticks */
#define PWM_MODULO      2400    /* 20kHz/50us @48MHz system clock */

/* Duty cycle limit for DC bus current measurement */
#define DC_THRESHOLD    400

/* PWM dead time in FTM2 ticks (if less than MC33937A dead time, then mask by MC33937A dead time) */
#define PWM_DEADTIME    19      /* ~400ns @48MHz FTM2 clock */

/* > MC33937 dead time + MC33937 high side turn ON time + phase ringing (in BUS/4 clock ticks) */
#define DELAY           18      /* 3us @ 6MHz */

/* DC Bus overcurrent limit (A) */
#define DCBUS_OVERCURR_THR      (((float)I_DCB_OVERCURRENT / (float)0x8000) * I_MAX)
/* DC Bus undervoltage limit (V) */
#define DCBUS_UNDERVOLT_THR     (((float)U_DCB_UNDERVOLTAGE / (float)0x8000) * U_DCB_MAX)

/* Speed increase step [RPM] */
#define SPEED_RPM_INC   400
/* Speed decrease step [RPM] */
#define SPEED_RPM_DEC   400
/* Maximal speed [RPM] */
#define SPEED_RPM_MAX   8000

/* Maximum number of stall check errors */
#define STALLCHECK_MAX_ERRORS		6
/* Minimal stall commutation period */
#define STALLCHECK_MIN_CMT_PERIOD	94	/* 20KRPM => 125us => 93.75 @750kHz */

/* User switch debounce timeout [ms] */
#define SW_PRESS_DEBOUNCE   75
/* User switch input blocking delay [ms] */
#define SW_PRESS_OFF        250

/********************** HW specific constants and macros **********************/
/* DC Bus voltage divider value */
#define DCBV_R_DIV              5.0
/* DC Bus current amplifier (MC33937A) gain */
#define DCBI_GAIN               12.0
/* DC Bus current amplifier (MC33937A) AMP_P input DC bias [V] */
#define DCBI_P_BIAS             2.5
/* DC Bus shunt resistor resistance [Ohm] */
#define DCBI_SHUNT_R            0.01
/* VDDA voltage [V] */
#define VDDA_VOLTAGE            5.0

/* Scaled speed increase step */
#define SPEED_INC   FRAC16(SPEED_RPM_INC/N_MAX)
/* Scaled speed decrease step */
#define SPEED_DEC   FRAC16(SPEED_RPM_DEC/N_MAX)
/* Scaled maximal speed */
#define SPEED_MAX   FRAC16(SPEED_RPM_MAX/N_MAX)

/* Analog comparators thresholds: DACVAL = (64 x Vthr/VDDA) - 1 */
/* "- 1" omitted for rounding */
#define ACMP0_DACVAL            (uint8_t)((64.0 * ((DCBUS_OVERCURR_THR * DCBI_SHUNT_R * DCBI_GAIN) + DCBI_P_BIAS)) / VDDA_VOLTAGE)
#define ACMP1_DACVAL            (uint8_t)((64.0 * (DCBUS_UNDERVOLT_THR / DCBV_R_DIV)) / VDDA_VOLTAGE)

#endif /* KEA128_APPCONFIG_H_ */
