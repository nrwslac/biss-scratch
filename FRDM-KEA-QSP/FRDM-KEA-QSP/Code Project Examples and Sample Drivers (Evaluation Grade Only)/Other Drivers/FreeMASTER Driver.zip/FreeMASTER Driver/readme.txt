This driver is meant for use in S32DS KEA projects for FreeMASTER enablement. It is compatible with the KEA SDK. KEAZ128/64 
and KEAZN32 all use UART2 to communicate with FreeMASTER.

Place typedefs.h inside the "include" folder of your project and integrate the folders "Sources" and "FM_control" by 
following the same steps as KEA SDK integration outlined in the software integration guide.